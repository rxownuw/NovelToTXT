import { useRef, useState, type FormEvent } from 'react';
import { Capacitor, CapacitorHttp, registerPlugin } from '@capacitor/core';
import { AlertCircle, Check, Download, FileText, Globe2, Square, BookOpen } from 'lucide-react';
import './index.css';

type DownloadFilePlugin = {
  saveToDownloads(options: { filename: string; content: string }): Promise<{ filename: string; uri: string }>;
};
const DownloadFile = registerPlugin<DownloadFilePlugin>('DownloadFile');

type Chapter = { url: string; title: string; content: string; error?: string };
const DEFAULT_URL = 'https://czbooks.net/n/aib7mb';

function safeFilename(value: string) {
  return value.normalize('NFKC').replace(/[<>:"/\\|?*\u0000-\u001f]/g, '')
    .replace(/\s+/g, ' ').trim().replace(/[. ]+$/g, '').slice(0, 90) || 'novel';
}
function cleanText(value: string) {
  return value.replace(/\u00a0/g, ' ').replace(/\r/g, '')
    .replace(/[ \t]+\n/g, '\n').replace(/\n[ \t]+/g, '\n')
    .replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
}
function absoluteUrl(href: string, base: string) {
  try { const u = new URL(href, base); if (!/^https?:$/.test(u.protocol)) return null; u.hash = ''; return u.href; }
  catch { return null; }
}
async function getHtml(url: string) {
  if (Capacitor.isNativePlatform()) {
    const response = await CapacitorHttp.get({ url, headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36' }, connectTimeout: 25000, readTimeout: 25000 });
    if (response.status < 200 || response.status >= 400) throw new Error(`HTTP ${response.status}`);
    return typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
  }
  const response = await fetch(url);
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return await response.text();
}
function getDocument(html: string) { return new DOMParser().parseFromString(html, 'text/html'); }
function normalizeTitle(doc: Document, fallback: string) {
  return (doc.querySelector('h1')?.textContent || doc.querySelector('title')?.textContent || fallback)
    .replace(/\s+/g, ' ').trim().slice(0, 160);
}
function extractLinks(doc: Document, pageUrl: string, rootUrl: URL) {
  const links: string[] = [];
  const seen = new Set<string>();
  const skip = /首頁|目录|目錄|上一章|下一章|上一页|下一页|下一頁|上一頁|登录|登入|注册|註冊|收藏|评论|評論|返回|章节目录|章節目錄/i;
  doc.querySelectorAll('a[href]').forEach(a => {
    const label = (a.textContent || '').replace(/\s+/g, ' ').trim();
    const href = absoluteUrl(a.getAttribute('href') || '', pageUrl);
    if (!href || !label || skip.test(label)) return;
    const u = new URL(href);
    if (u.hostname !== rootUrl.hostname) return;
    if (href === pageUrl || seen.has(href)) return;
    // Keep links within the novel's path family, avoiding site-wide navigation.
    const rootParts = rootUrl.pathname.split('/').filter(Boolean);
    const pathParts = u.pathname.split('/').filter(Boolean);
    const sameFamily = u.pathname.startsWith(rootUrl.pathname.replace(/\/$/, '') + '/') ||
      (rootParts.length > 0 && pathParts.length >= rootParts.length && rootParts.every((p, i) => pathParts[i] === p)) ||
      u.pathname === rootUrl.pathname;
    const likelyChapter = /章|回|節|节|卷|序|楔子|番外|chapter|episode|\d/.test(label) ||
      /chapter|read|book|novel|\/n\/|\/\d+/.test(u.pathname);
    if (sameFamily && likelyChapter) { seen.add(href); links.push(href); }
  });
  return links;
}
function findNextPage(doc: Document, pageUrl: string, rootUrl: URL) {
  const rel = doc.querySelector('a[rel="next"]');
  if (rel) return absoluteUrl(rel.getAttribute('href') || '', pageUrl);
  const candidates = Array.from(doc.querySelectorAll('a[href]'));
  const a = candidates.find(x => /下一页|下一頁|下页|下頁|next|後頁|后页/i.test((x.textContent || '').trim()));
  if (!a) return null;
  const href = absoluteUrl(a.getAttribute('href') || '', pageUrl);
  if (!href) return null;
  try { return new URL(href).hostname === rootUrl.hostname ? href : null; } catch { return null; }
}
function extractChapter(html: string, url: string): Chapter {
  const doc = getDocument(html);
  const title = normalizeTitle(doc, url);
  doc.querySelectorAll('script,style,noscript,svg,iframe,form,nav,footer,header,aside,button,.ads,.ad,.advertisement,[class*="comment"],[id*="comment"],[class*="recommend"],[class*="footer"],[class*="nav"]').forEach(n => n.remove());
  const selectors = ['#chapter-content','#content','#chapter','.chapter-content','.chapter_body','.chapter-body','.read-content','.read_content','.reader-content','.article-content','.entry-content','article main','article','main'];
  let best: Element | null = null, bestScore = 0;
  for (const selector of selectors) {
    doc.querySelectorAll(selector).forEach(el => {
      const text = (el.textContent || '').trim();
      const score = text.length - el.querySelectorAll('a').length * 20;
      if (score > bestScore) { best = el; bestScore = score; }
    });
  }
  const container = best || doc.body;
  container.querySelectorAll('br').forEach(n => n.replaceWith(doc.createTextNode('\n')));
  container.querySelectorAll('p,div,section,h1,h2,h3,h4,li,blockquote').forEach(n => {
    n.insertBefore(doc.createTextNode('\n'), n.firstChild);
    n.appendChild(doc.createTextNode('\n'));
  });
  let content = cleanText(container.textContent || '');
  if (content.length < 80) throw new Error('找不到足夠的章節正文，可能是網站版型不相容或需要登入');
  return { url, title, content };
}

export default function App() {
  const [url, setUrl] = useState(DEFAULT_URL);
  const [novelTitle, setNovelTitle] = useState('');
  const [filename, setFilename] = useState('小說全文.txt');
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [status, setStatus] = useState('輸入小說目錄網址後，開始整理章節。');
  const [error, setError] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [delay, setDelay] = useState(900);
  const stopRef = useRef(false);
  const [progress, setProgress] = useState(0);

  const stop = () => { stopRef.current = true; setStatus('正在停止，會保留已抓取的章節…'); };

  const handleExtract = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(''); setChapters([]); setIsReady(false); setProgress(0);
    let start: URL;
    try { start = new URL(url.trim()); if (!/^https?:$/.test(start.protocol)) throw new Error(); }
    catch { setError('請輸入有效的 http:// 或 https:// 網址。'); return; }
    stopRef.current = false; setIsRunning(true);
    try {
      setStatus('正在讀取小說目錄…');
      const queue: string[] = [];
      const visitedPages = new Set<string>();
      let page: string | null = start.href;
      let title = '';
      while (page && !visitedPages.has(page) && visitedPages.size < 60 && !stopRef.current) {
        visitedPages.add(page);
        const html = await getHtml(page);
        const doc = getDocument(html);
        if (!title) title = normalizeTitle(doc, '小說');
        extractLinks(doc, page, start).forEach(link => { if (!queue.includes(link)) queue.push(link); });
        const next = findNextPage(doc, page, start);
        page = next && !visitedPages.has(next) ? next : null;
        setStatus(`已整理目錄頁 ${visitedPages.size} 頁，找到 ${queue.length} 個候選章節…`);
        if (page) await new Promise(r => setTimeout(r, 350));
      }
      if (!queue.length) throw new Error('目錄頁沒有找到章節連結。請確認網址是小說目錄頁，而非單一章節頁。');
      setNovelTitle(title);
      setFilename(`${safeFilename(title)}.txt`);
      const results: Chapter[] = [];
      for (let i = 0; i < queue.length && !stopRef.current; i++) {
        const chapterUrl = queue[i];
        try {
          const html = await getHtml(chapterUrl);
          const chapter = extractChapter(html, chapterUrl);
          results.push(chapter);
          setStatus(`正在抓取第 ${i + 1} / ${queue.length} 章：${chapter.title}`);
        } catch (e) {
          results.push({ url: chapterUrl, title: `第 ${i + 1} 章（抓取失敗）`, content: '', error: e instanceof Error ? e.message : String(e) });
          setStatus(`第 ${i + 1} / ${queue.length} 章抓取失敗，繼續下一章…`);
        }
        setChapters([...results]);
        setProgress(Math.round(((i + 1) / queue.length) * 100));
        if (i < queue.length - 1 && !stopRef.current) await new Promise(r => setTimeout(r, Math.max(300, Math.min(5000, delay))));
      }
      setChapters(results);
      setIsReady(results.some(c => c.content.length > 0));
      setStatus(stopRef.current ? `已停止。保留 ${results.filter(c => c.content).length} 章成功內容。` : `完成！成功 ${results.filter(c => c.content).length} 章，失敗 ${results.filter(c => c.error).length} 章。`);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setStatus('抓取未完成。');
    } finally { setIsRunning(false); }
  };

  const handleDownload = async () => {
    const body = chapters.map((c, i) => c.content
      ? `\n\n${'='.repeat(24)}\n${c.title}\n${'='.repeat(24)}\n\n${c.content}`
      : `\n\n${'='.repeat(24)}\n${c.title}\n${'='.repeat(24)}\n\n[本章抓取失敗：${c.error || '未知錯誤'}]\n原始網址：${c.url}`).join('\n');
    const text = `${novelTitle || '小說'}\n來源：${url}\n章節數：${chapters.length}\n\n${body}\n`;
    const finalName = safeFilename(filename.replace(/\.txt$/i, '')) + '.txt';
    try {
      if (Capacitor.isNativePlatform()) {
        const result = await DownloadFile.saveToDownloads({ filename: finalName, content: text });
        setStatus(`已儲存至 Download：${result.filename}`);
      } else {
        const blob = new Blob(['\ufeff', text], { type: 'text/plain;charset=utf-8' });
        const href = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = href; a.download = finalName; a.click();
        URL.revokeObjectURL(href); setStatus('TXT 已下載。');
      }
    } catch (e) { setError(`儲存失敗：${e instanceof Error ? e.message : String(e)}`); }
  };

  const successCount = chapters.filter(c => c.content).length;
  const failedCount = chapters.filter(c => c.error).length;
  return <main className="app-shell">
    <header className="topbar"><div className="brand"><div className="brand-mark"><BookOpen size={22}/></div><div><strong>BlogToTXT</strong><small>小說合併版</small></div></div><span className="version-tag">NOVEL</span></header>
    <div className="main-content">
    <section className="intro"><div className="eyebrow">NOVEL TO TEXT</div><div className="intro-icon"><FileText size={25}/></div><h1>小說目錄轉 TXT</h1><p>自動整理目錄章節，依序擷取全文，合併成一份純文字檔。</p></section>
    <section className="workspace">
      <form className="url-panel" onSubmit={handleExtract}>
        <div className="panel-heading"><Globe2 size={19}/><h2>小說目錄網址</h2></div>
        <label htmlFor="novel-url">貼上小說目錄頁連結</label>
        <input id="novel-url" className="url-input" value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://…" disabled={isRunning}/>
        <div className="settings-row"><label htmlFor="delay">每章間隔</label><select id="delay" value={delay} onChange={e=>setDelay(Number(e.target.value))} disabled={isRunning}><option value={500}>0.5 秒</option><option value={900}>0.9 秒（建議）</option><option value={1500}>1.5 秒</option><option value={2500}>2.5 秒</option></select></div>
        <div className="action-row">{!isRunning ? <button className="extract-button" type="submit"><Globe2 size={18}/> 開始抓取小說</button> : <button className="extract-button" type="button" onClick={stop}><Square size={16}/> 停止抓取</button>}</div>
      </form>
      <section className="editor-panel">
        <div className="panel-heading"><FileText size={19}/><h2>抓取進度</h2></div>
        <div className="progress-track"><div className="progress-fill" style={{width:`${progress}%`}}/></div>
        <div className="progress-meta"><span>{status}</span><strong>{progress}%</strong></div>
        {error && <div className="status-message error"><AlertCircle size={17}/>{error}</div>}
        {chapters.length > 0 && <div className="chapter-summary"><div className="summary-number">{chapters.length}<small>找到章節</small></div><div className="summary-number">{successCount}<small>成功</small></div><div className="summary-number">{failedCount}<small>失敗</small></div></div>}
        {chapters.length > 0 && <div className="chapter-list">{chapters.slice(0, 12).map((c,i)=><div className="chapter-item" key={c.url}><span>{i+1}.</span><span>{c.title}</span>{c.error && <AlertCircle size={15}/>}</div>)}{chapters.length>12 && <small>其餘 {chapters.length-12} 章已收錄…</small>}</div>}
        {isReady && <div className="status-message success"><Check size={17}/>已整理完成，可以合併下載。</div>}
      </section>
      <section className="download-panel">
        <div className="panel-heading"><Download size={19}/><h2>合併下載</h2></div>
        <label htmlFor="filename">TXT 檔名</label><input id="filename" className="url-input" value={filename} onChange={e=>setFilename(e.target.value)} disabled={!isReady}/>
        <button className="download-button" type="button" onClick={handleDownload} disabled={!isReady}><Download size={18}/> 下載純文字檔</button>
        <p className="download-hint">Android 版本會直接儲存到手機的 Download 資料夾。</p>
      </section>
    </section>
    </div>
    <footer className="app-footer">請僅擷取你有權保存的內容，並遵守網站使用條款與著作權規定。</footer>
  </main>;
}
