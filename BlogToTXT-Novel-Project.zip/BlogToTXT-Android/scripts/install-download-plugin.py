#!/usr/bin/env python3
from pathlib import Path
import json, re
root = Path(__file__).resolve().parents[1]
package = json.loads((root / 'capacitor.config.json').read_text())['appId']
android = root / 'android' / 'app' / 'src' / 'main'
java_root = android / 'java' / Path(*package.split('.'))
java_root.mkdir(parents=True, exist_ok=True)
plugin = java_root / 'DownloadFilePlugin.java'
plugin.write_text('''package PACKAGE_NAME;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

@CapacitorPlugin(name = "DownloadFile")
public class DownloadFilePlugin extends Plugin {
    @PluginMethod
    public void saveToDownloads(PluginCall call) {
        String filename = call.getString("filename");
        String content = call.getString("content");
        if (filename == null || filename.trim().isEmpty() || content == null) {
            call.reject("缺少檔名或文字內容");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("此版本 Android 不支援直接寫入公開下載資料夾（需要 Android 10 以上）");
            return;
        }
        Uri uri = null;
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, "text/plain");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            uri = getContext().getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("無法建立下載檔案");
            try (OutputStream stream = getContext().getContentResolver().openOutputStream(uri)) {
                if (stream == null) throw new Exception("無法寫入下載檔案");
                stream.write(content.getBytes(StandardCharsets.UTF_8));
                stream.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Downloads.IS_PENDING, 0);
            getContext().getContentResolver().update(uri, done, null, null);
            JSObject result = new JSObject();
            result.put("filename", filename);
            result.put("uri", uri.toString());
            call.resolve(result);
        } catch (Exception e) {
            if (uri != null) getContext().getContentResolver().delete(uri, null, null);
            call.reject("儲存到下載資料夾失敗：" + e.getMessage(), e);
        }
    }
}
'''.replace('PACKAGE_NAME', package))
# Register native plugin with generated Capacitor activity.
main_files = list((android / 'java').rglob('MainActivity.java'))
if not main_files:
    raise SystemExit('找不到 MainActivity.java')
main = main_files[0]
t = main.read_text()
if 'DownloadFilePlugin' not in t:
    t = t.replace('import com.getcapacitor.BridgeActivity;', 'import com.getcapacitor.BridgeActivity;\nimport ' + package + '.DownloadFilePlugin;')
    pattern = r'public class MainActivity extends BridgeActivity\s*\{\s*\}'
    replacement = '''public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        registerPlugin(DownloadFilePlugin.class);
        super.onCreate(savedInstanceState);
    }
}'''
    t, count = re.subn(pattern, replacement, t)
    if count != 1:
        raise SystemExit('無法自動註冊 DownloadFilePlugin：' + str(main))
    main.write_text(t)
print('Installed DownloadFilePlugin:', main)
