# NovelToTXT

## 功能
- 輸入小說目錄網址，掃描目錄頁章節連結與下一頁。
- 依目錄頁出現順序逐章擷取並合併。
- 顯示抓取進度、成功/失敗數量，支援停止。
- 輸出 UTF-8 TXT；Android 10 以上直接寫入 Download。
- 使用獨立 App ID：`tw.blogtotxt.novel`，不覆蓋其他 BlogToTXT 版本。

## GitHub Actions
1. 將 `BlogToTXT-Novel-Project.zip` 放在 GitHub Repository 根目錄。
2. 將本 ZIP 內的 `build-apk.yml` 內容貼到 `.github/workflows/build-apk.yml`。
3. Push 到 `main`，或到 Actions 手動執行 `Build BlogToTXT Novel APK`。
4. 完成後在該次 workflow 的 Artifacts 下載 `NovelToTXT-APK`。

## 注意
不同小說網站的目錄/正文 HTML 結構不一樣。本版本使用通用連結與正文選擇器，並非已針對所有網站驗證。若網站有登入、反爬蟲、JavaScript 動態載入或特殊章節分頁，可能需要再針對該網站調整。請遵守網站條款與著作權規定。


編譯完成後，下載的 APK 檔名為 `NovelToTXT.apk`，手機桌面顯示名稱為 `NovelToTXT`。
